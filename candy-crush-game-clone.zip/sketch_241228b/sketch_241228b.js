let grid;
let cols = 8;
let rows = 8;
let candyTypes = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'];
let candySize = 50;
let selectedCandy = null;
let isSwapping = false;
let dragCandy = null;
let targetCandy = null;
let score = 0;
let candyImages = {};
let imagesLoaded = 0;
let totalImages = candyTypes.length;

function preload() {
  candyTypes.forEach(candy => {
    // Load and resize candy images to fit the grid
    candyImages[candy] = loadImage('sketch_241228b/' + candy + '.png', 
      () => {
        candyImages[candy].resize(candySize, candySize);  // Resize image to match candy size
        imagesLoaded++;
        console.log(`${candy} image loaded and resized!`);
      }, 
      (error) => console.log(`${candy} image failed to load: ${error}`)
    );
  });
}

function setup() {
  createCanvas(400, 400);
  frameRate(30);
}

function draw() {
  if (imagesLoaded < totalImages) {
    showLoadingMessage();  // Display loading message until all images are loaded
    return;
  }

  if (!grid) {
    grid = createGrid(cols, rows);  // Create grid once images are loaded
  }

  background(255);
  drawGrid();

  if (dragCandy) {
    drawCandyWithGlow(mouseX - candySize / 2, mouseY - candySize / 2, candySize, dragCandy.type);
  }

  if (isSwapping) {
    checkMatches();
  }

  displayScore();
}

// Create a random grid of candies
function createGrid(cols, rows) {
  let newGrid = [];
  for (let i = 0; i < cols; i++) {
    newGrid[i] = [];
    for (let j = 0; j < rows; j++) {
      let randomCandy = random(candyTypes);
      newGrid[i][j] = { type: randomCandy, x: i, y: j };
    }
  }
  return newGrid;
}

// Draw the grid of candies
function drawGrid() {
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      let x = i * candySize;
      let y = j * candySize;
      image(candyImages[grid[i][j].type], x, y, candySize, candySize); // Draw each candy image
    }
  }
}

// Handle mouse press events to select a candy
function mousePressed() {
  let col = floor(mouseX / candySize);
  let row = floor(mouseY / candySize);

  if (col < cols && row < rows) {
    dragCandy = grid[col][row];
    targetCandy = null;
  }
}

// Handle mouse dragged events to update the drag position
function mouseDragged() {
  if (dragCandy) {
    let col = floor(mouseX / candySize);
    let row = floor(mouseY / candySize);

    if (col < cols && row < rows && isAdjacent(dragCandy, grid[col][row])) {
      targetCandy = grid[col][row];
    }
  }
}

// Handle mouse release events to swap candies
function mouseReleased() {
  if (dragCandy && targetCandy && isAdjacent(dragCandy, targetCandy)) {
    swapCandies(dragCandy, targetCandy);
    isSwapping = true;
    dragCandy = null;
    targetCandy = null;
  } else {
    dragCandy = null;
    targetCandy = null;
  }
}

// Check if two candies are adjacent
function isAdjacent(candy1, candy2) {
  return (abs(candy1.x - candy2.x) === 1 && candy1.y === candy2.y) ||
         (abs(candy1.y - candy2.y) === 1 && candy1.x === candy2.x);
}

// Swap the candies
function swapCandies(candy1, candy2) {
  let temp = candy1.type;
  candy1.type = candy2.type;
  candy2.type = temp;
}

// Check for matches and remove candies if necessary
function checkMatches() {
  let matches = [];

  // Check for horizontal matches
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows - 2; j++) {
      if (grid[i][j].type === grid[i][j + 1].type && grid[i][j + 1].type === grid[i][j + 2].type) {
        matches.push({ i, j, direction: 'horizontal' });
      }
    }
  }

  // Check for vertical matches
  for (let i = 0; i < cols - 2; i++) {
    for (let j = 0; j < rows; j++) {
      if (grid[i][j].type === grid[i + 1][j].type && grid[i + 1][j].type === grid[i + 2][j].type) {
        matches.push({ i, j, direction: 'vertical' });
      }
    }
  }

  if (matches.length > 0) {
    removeMatches(matches);
    score += matches.length * 10;  // Increase score by number of matches
    isSwapping = false;
  } else {
    isSwapping = false;
  }
}

// Remove matched candies and refill the grid
function removeMatches(matches) {
  for (let match of matches) {
    if (match.direction === 'horizontal') {
      for (let j = 0; j < 3; j++) {
        grid[match.i][match.j + j].type = null;
      }
    } else if (match.direction === 'vertical') {
      for (let i = 0; i < 3; i++) {
        grid[match.i + i][match.j].type = null;
      }
    }
  }

  // Fill empty spaces and drop candies
  for (let i = 0; i < cols; i++) {
    for (let j = rows - 1; j >= 0; j--) {
      if (grid[i][j].type === null) {
        for (let k = j; k > 0; k--) {
          grid[i][k].type = grid[i][k - 1].type;
        }
        grid[i][0].type = random(candyTypes);
      }
    }
  }
}

// Display loading message
function showLoadingMessage() {
  background(255);
  textSize(24);
  fill(0);
  textAlign(CENTER, CENTER);
  text("Loading images...", width / 2, height / 2);
}

// Display score on the canvas
function displayScore() {
  textSize(24);
  fill(0);
  text('Score: ' + score, width - 120, 30);
}
